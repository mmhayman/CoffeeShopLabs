CREATE VIEW northwind.invoices AS
  SELECT
    `northwind`.`orders`.`ShipName`                                                    AS `ShipName`,
    `northwind`.`orders`.`ShipAddress`                                                 AS `ShipAddress`,
    `northwind`.`orders`.`ShipCity`                                                    AS `ShipCity`,
    `northwind`.`orders`.`ShipRegion`                                                  AS `ShipRegion`,
    `northwind`.`orders`.`ShipPostalCode`                                              AS `ShipPostalCode`,
    `northwind`.`orders`.`ShipCountry`                                                 AS `ShipCountry`,
    `northwind`.`orders`.`CustomerID`                                                  AS `CustomerID`,
    `northwind`.`customers`.`CompanyName`                                              AS `CustomerName`,
    `northwind`.`customers`.`Address`                                                  AS `Address`,
    `northwind`.`customers`.`City`                                                     AS `City`,
    `northwind`.`customers`.`Region`                                                   AS `Region`,
    `northwind`.`customers`.`PostalCode`                                               AS `PostalCode`,
    `northwind`.`customers`.`Country`                                                  AS `Country`,
    ((`northwind`.`employees`.`FirstName` + ' ') + `northwind`.`employees`.`LastName`) AS `Salesperson`,
    `northwind`.`orders`.`OrderID`                                                     AS `OrderID`,
    `northwind`.`orders`.`OrderDate`                                                   AS `OrderDate`,
    `northwind`.`orders`.`RequiredDate`                                                AS `RequiredDate`,
    `northwind`.`orders`.`ShippedDate`                                                 AS `ShippedDate`,
    `northwind`.`shippers`.`CompanyName`                                               AS `ShipperName`,
    `northwind`.`order details`.`ProductID`                                            AS `ProductID`,
    `northwind`.`products`.`ProductName`                                               AS `ProductName`,
    `northwind`.`order details`.`UnitPrice`                                            AS `UnitPrice`,
    `northwind`.`order details`.`Quantity`                                             AS `Quantity`,
    `northwind`.`order details`.`Discount`                                             AS `Discount`,
    ((((`northwind`.`order details`.`UnitPrice` * `northwind`.`order details`.`Quantity`) *
       (1 - `northwind`.`order details`.`Discount`)) / 100) * 100)                     AS `ExtendedPrice`,
    `northwind`.`orders`.`Freight`                                                     AS `Freight`
  FROM (((((`northwind`.`customers`
    JOIN `northwind`.`orders` ON ((`northwind`.`customers`.`CustomerID` = `northwind`.`orders`.`CustomerID`))) JOIN
    `northwind`.`employees` ON ((`northwind`.`employees`.`EmployeeID` = `northwind`.`orders`.`EmployeeID`))) JOIN
    `northwind`.`order details` ON ((`northwind`.`orders`.`OrderID` = `northwind`.`order details`.`OrderID`))) JOIN
    `northwind`.`products` ON ((`northwind`.`products`.`ProductID` = `northwind`.`order details`.`ProductID`))) JOIN
    `northwind`.`shippers` ON ((`northwind`.`shippers`.`ShipperID` = `northwind`.`orders`.`ShipVia`)));
