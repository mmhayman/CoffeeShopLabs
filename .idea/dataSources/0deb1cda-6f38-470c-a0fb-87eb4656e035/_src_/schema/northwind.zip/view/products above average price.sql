CREATE VIEW northwind.`products above average price` AS
  SELECT
    `northwind`.`products`.`ProductName` AS `ProductName`,
    `northwind`.`products`.`UnitPrice`   AS `UnitPrice`
  FROM `northwind`.`products`
  WHERE (`northwind`.`products`.`UnitPrice` > (SELECT avg(`northwind`.`products`.`UnitPrice`)
                                               FROM `northwind`.`products`));
