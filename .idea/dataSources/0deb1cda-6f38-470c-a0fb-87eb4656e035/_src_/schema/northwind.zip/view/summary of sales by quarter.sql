CREATE VIEW northwind.`summary of sales by quarter` AS
  SELECT
    `northwind`.`orders`.`ShippedDate` AS `ShippedDate`,
    `northwind`.`orders`.`OrderID`     AS `OrderID`,
    `order subtotals`.`Subtotal`       AS `Subtotal`
  FROM (`northwind`.`orders`
    JOIN `northwind`.`order subtotals` ON ((`northwind`.`orders`.`OrderID` = `order subtotals`.`OrderID`)))
  WHERE (`northwind`.`orders`.`ShippedDate` IS NOT NULL);
