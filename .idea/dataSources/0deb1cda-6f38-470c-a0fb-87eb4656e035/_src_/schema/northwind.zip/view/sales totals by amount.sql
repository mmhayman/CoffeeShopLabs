CREATE VIEW northwind.`sales totals by amount` AS
  SELECT
    `order subtotals`.`Subtotal`          AS `SaleAmount`,
    `northwind`.`orders`.`OrderID`        AS `OrderID`,
    `northwind`.`customers`.`CompanyName` AS `CompanyName`,
    `northwind`.`orders`.`ShippedDate`    AS `ShippedDate`
  FROM ((`northwind`.`customers`
    JOIN `northwind`.`orders` ON ((`northwind`.`customers`.`CustomerID` = `northwind`.`orders`.`CustomerID`))) JOIN
    `northwind`.`order subtotals` ON ((`northwind`.`orders`.`OrderID` = `order subtotals`.`OrderID`)))
  WHERE ((`order subtotals`.`Subtotal` > 2500) AND
         (`northwind`.`orders`.`ShippedDate` BETWEEN '1997-01-01' AND '1997-12-31'));
