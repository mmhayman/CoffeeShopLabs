CREATE FUNCTION northwind.DateOnly(InDateTime DATETIME)
  RETURNS VARCHAR(10)
  BEGIN

  DECLARE MyOutput varchar(10);
	SET MyOutput = DATE_FORMAT(InDateTime,'%Y-%m-%d');

  RETURN MyOutput;

END;
