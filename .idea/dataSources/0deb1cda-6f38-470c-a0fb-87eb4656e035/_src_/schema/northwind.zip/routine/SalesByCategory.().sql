CREATE PROCEDURE northwind.SalesByCategory()
  BEGIN

END;
